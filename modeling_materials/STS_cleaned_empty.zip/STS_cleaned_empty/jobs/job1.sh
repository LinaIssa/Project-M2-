#!/bin/bash
#SBATCH -N 5
#SBATCH --tasks-per-node=32
#SBATCH -t 1-00:00:00
#SBATCH -p broadwell
#SBATCH --job-name=stsrun1

# script from Devarshi; change DIR NAMES & FILE (ini and main) NAMES

echo start of job in directory $SLURM_SUBMIT_DIR
echo number of nodes is $SLURM_JOB_NUM_NODES
echo the allocated nodes are:
echo $SLURM_JOB_NODELIST

module load pre2019
module load intel/2017b
module load python/2.7.9

cp -r $HOME/NICER_analyses/TEST_RUNS/J0030/STS/ "$TMPDIR"
echo $TMPDIR
cd "$TMPDIR"/STS/STS_module/

export PYTHONPATH=$HOME/.local/lib/python2.7/site-packages/:$PYTHONPATH
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export GOTO_NUM_THREADS=1
export MKL_NUM_THREADS=1
export LD_LIBRARY_PATH=$HOME/multinest/MultiNest_v3.12_CMake/multinest/lib:$LD_LIBRARY_PATH

srun python main.py @config.ini --multinest > out_run1 2> err_run1

cp out_run1 err_run1 run1* $HOME/NICER_analyses/TEST_RUNS/J0030/STS/STS_outputs/run1/.

#end of job file
